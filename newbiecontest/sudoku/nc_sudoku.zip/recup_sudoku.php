<?php

//***fonction connect($path), argument : $path / returns réponse server :  $output
function connect($path)
{
	sleep(1);
	echo "\r\n\r\n* CONNEXION à : ".$path."\r\n";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $path);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_COOKIE,"SMFCookie89=a%3A4%3A%7Bi%3A0%3Bs%3A3%3A%22534%22%3Bi%3A1%3Bs%3A40%3A%22dc94d4515f17debbc6849568f03a6d9e8160d78b%22%3Bi%3A2%3Bi%3A1623275255%3Bi%3A3%3Bi%3A0%3B%7D;PHPSESSID=f79639076c21952f4de51ce482f75943;  admin=0") ;
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output=curl_exec($ch);
	curl_close($ch);
	echo "\r\n\r\n* REPONSE DE : ".$path."\r\n\r\n";
	echo $output;
	echo "\r\n\r\n* FIN DE REPONSE \r\n\r\n";
	return $output;
}
//***fin de la fonction connect***

// connexion a progcrawlme.php
$path="https://www.newbiecontest.org/epreuves/prog/progsudoku.php";
$init_connect=connect($path);

//extraction de la grille de sudoku
$split=explode("</td>",$init_connect);

//print_r($split);
$i=0;
foreach ($split as $value)
{
	$numero[$i]=substr("$value",-1);
	if (is_numeric($numero[$i])) 
	{
	$i++;
	}
	
}
array_pop($numero);
print_r($numero);



//Formatage bien degueu de la grille 

$ligne0=$numero[0].$numero[1].$numero[2].$numero[9].$numero[10].$numero[11].$numero[18].$numero[19].$numero[20];
$ligne1=$numero[3].$numero[4].$numero[5].$numero[12].$numero[13].$numero[14].$numero[21].$numero[22].$numero[23];
$ligne2=$numero[6].$numero[7].$numero[8].$numero[15].$numero[16].$numero[17].$numero[24].$numero[25].$numero[26];
$ligne3=$numero[27].$numero[28].$numero[29].$numero[36].$numero[37].$numero[38].$numero[45].$numero[46].$numero[47];
$ligne4=$numero[30].$numero[31].$numero[32].$numero[39].$numero[40].$numero[41].$numero[48].$numero[49].$numero[50];
$ligne5=$numero[33].$numero[34].$numero[35].$numero[42].$numero[43].$numero[44].$numero[51].$numero[52].$numero[53];
$ligne6=$numero[54].$numero[55].$numero[56].$numero[63].$numero[64].$numero[65].$numero[72].$numero[73].$numero[74];
$ligne7=$numero[57].$numero[58].$numero[59].$numero[66].$numero[67].$numero[68].$numero[75].$numero[76].$numero[77];
$ligne8=$numero[60].$numero[61].$numero[62].$numero[69].$numero[70].$numero[71].$numero[78].$numero[79].$numero[80];

$concat=$ligne0.$ligne1.$ligne2.$ligne3.$ligne4.$ligne5.$ligne6.$ligne7.$ligne8;
$grille=str_split($concat);

echo "\r\n\r\ngrille formatee ligne par ligne : ";
print_r($grille);

// end of Bullshit



?>
