#!/bin/bash
# Indique au système que l'argument qui suit est le programme utilisé pour exécuter ce fichier
# En règle générale, les "#" servent à mettre en commentaire le texte qui suit comme ici
echo Newbiecontest epreuve sudoku start
php5 nc_sudoku.php >out2.txt
sleep 1
php5 nc_sudoku_send.php
 
exit 0
